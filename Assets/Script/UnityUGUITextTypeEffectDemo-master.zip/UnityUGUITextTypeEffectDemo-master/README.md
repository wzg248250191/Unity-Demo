这是我使用Unity UGUI制作的一个文本打字效果Demo，支持富文本  
我对应的博客文章：https://linxinfa.blog.csdn.net/article/details/115461154  
![](https://img-blog.csdnimg.cn/20210406150132265.gif)
